#ifndef SERVER_HPP
#define SERVER_HPP

#include "Client.hpp"
#include <string>
#include <map>
#include <vector>
#include <netinet/in.h>

class Server
{
private:
    int _port;
    std::string _password;
    int _server_fd;
    struct sockaddr_in _address;

    std::map<int, Client> _clients;
    std::vector<struct pollfd> _pollfds;

    void setupServerSocket();
    void makeNonBlocking(int fd);
    void handleNewConnection();
    void handleClientInput(int fd);
    void sendClientData(int fd);
    void disconnectClient(int fd);
    void errorExit(const std::string &msg);

public:
    Server(int port, const std::string &password);
    ~Server();

    void start();

    void sendToClient(int fd, const std::string &msg);


    void eventLoop();
};

#endif 