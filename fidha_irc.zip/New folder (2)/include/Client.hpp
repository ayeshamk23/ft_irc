#ifndef CLIENT_HPP
#define CLIENT_HPP

#include <string>

class Client 
{
    private:
        int fd;
        std::string buffer_in;
        std::string buffer_out;
        bool registered;
        std::string nickname;

    public:

    Client() : fd(-1), buffer_in(""), buffer_out(""), registered(false) {}
    Client(int fd_) : fd(fd_), buffer_in(""), buffer_out(""), registered(false) {}

    int getFd() const { return fd; }
    void setFd(int newFd) { fd = newFd; }

    bool isRegistered() const { return registered; }
    void setRegistered(bool status) { registered = status; }


    std::string getBufferIn() const { return buffer_in; }
    std::string getBufferOut() const { return buffer_out; }

    std::string& getBufferInRef() { return buffer_in; }
    std::string& getBufferOutRef() { return buffer_out; }

};

#endif
